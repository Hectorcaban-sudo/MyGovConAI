from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import httpx

from chroma.search import drive_id_filter, hybrid_rank_results, normalize_results
from config import Settings, ssl_verify_setting
from llm.client import LLMClient
import chromadb

class ChromaClient:
    def __init__(
        self,
        settings: Settings,
        embeddings: LLMClient,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._settings = settings
        self._embeddings = embeddings
        authorization = (
            f"{settings.chroma_auth_scheme} {settings.chroma_auth_token}".strip()
            if settings.chroma_auth_scheme
            else settings.chroma_auth_token
        )
        self._client = client or httpx.AsyncClient(
            base_url=settings.chroma_url.rstrip("/") + "/",
            headers={settings.chroma_auth_header: authorization},
            timeout=settings.request_timeout_seconds,
            verify=ssl_verify_setting(settings),
        )
        self._owns_client = client is None
        self._chromaClient = client = chromadb.HttpClient(host="10.73.89.168", port=9000, ssl=False, headers={"Authorization": settings.chroma_auth_header})

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def search_contracts(
        self, query: str, file_ids: list[str] | None = None
    ) -> list[dict[str, Any]]:
        return await self._search(self._settings.chroma_contract_collection, query, file_ids or [])

    async def search_reference(self, query: str) -> list[dict[str, Any]]:
        return await self._search(self._settings.chroma_reference_collection, query, [])

    async def _search(
        self, collection: str, query: str, file_ids: list[str]
    ) -> list[dict[str, Any]]:
        self._settings.require_chroma()
        embedding = await self._embeddings.embed(query)
        result_limit = (
            self._settings.chroma_top_k if file_ids else self._settings.chroma_candidate_k
        )
        payload: dict[str, Any] = {
            "query_embeddings": [embedding],
            "n_results": result_limit,
            "include": ["documents", "metadatas", "distances"],
        }
        where = drive_id_filter(file_ids[: self._settings.max_file_ids])
        if where is not None:
            payload["where"] = where
        collection_path = (
            f"api/v2/tenants/{self._settings.chroma_tenant}"
            f"/databases/{self._settings.chroma_database}/collections"
        )
        # collection_response = await self._client.get(f"{collection_path}/{collection}")
        # collection_response.raise_for_status()
        # collection_id = collection_response.json()["id"]
        collection = self._chromaClient.get_or_create_collection(name="IS_contracts_full_main_e5_documents")
        
        try:
            response = collection.query(query_embeddings=embedding)
            # response = await self._client.post(
            #     f"{collection_path}/{collection_id}/query", json=payload
            # )
        except httpx.ReadTimeout:
            if file_ids or result_limit == self._settings.chroma_top_k:
                raise
            payload["n_results"] = self._settings.chroma_top_k
            response = await self._client.post(
                f"{collection_path}/{collection_id}/query", json=payload
            )
        #response.raise_for_status()
        #response2 = SimpleNamespace(**response)
        if file_ids:
            return normalize_results(response, None)
        return hybrid_rank_results(query, response, self._settings.chroma_top_k)
